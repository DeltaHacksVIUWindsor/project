# DeltaHacks: UWindsor Team Project Submission
## Project Idea
Homeless Access Application

## Description
An application that helps connect the homeless with relevant resources based on their needs and their location

## Functionality
Users may:
* find local homeless shelters
* find education resources
* find free resources
* connect with those who would like to help


## Technologies Used
* HTML, CSS
* Bootstrap
* Google maps api
* flutter